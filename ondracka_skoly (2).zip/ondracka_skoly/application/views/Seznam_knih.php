<!DOCTYPE html> 
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
</head>
 
   <head> 
      <meta charset = "utf-8"> 
      <title>Seznam knih</title> 
      <style>
          table{
              color:red;
              border: 8px solid orange;
          }
      </style>
   </head> 
    <div class="container" style="text-align: center;">
       <h1 style="margin-top: 60px; color: skyblue;"><i class="fas fa-book-open"></i> SEZNAM KNIH </h1>
       <br>
       <br>
       <?php
            $this->load->view('layout/menu');
        ?>
       <div style="margin-top: 50px; text-align: center" class="bg-dark">
      
		
      <table class="table table-hover table-bordered table-dark" border = "1" style="margin-top: 20px; color: skyblue;" id="dtBasicExample"> 
         <?php 
            $i = 1; 
            echo "<tr class='bg-dark text-light'>";
            echo "<td><b>NÁZEV KNIHY</b></td>";  
            echo "<td><b>ROK VYDÁNÍ</b></td>"; 
            echo "<td><b>ISBN</b></td>"; 
            echo "<tr>"; 
				
            foreach($kniha as $k) { 
               echo "<tr>"; 
               echo "<td>".$k->nazev."</td>"; 
               echo "<td>".$k->vydani."</td>"; 
               echo "<td>".$k->isbn."</td>"; 
               echo "<tr>"; 
            } 
         ?>
       
</table> 
          
           <nav aria-label="...">
  <ul class="pagination pagination-sm justify-content-center">
      <li class="page-item">
          <a class="page-link bg-dark text-light"  href="http://localhost/ondracka_knihovna/Nacteni_seznamu/Seznam_knih" tabindex="-1"><b style="color: skyblue;">1</b></a>
    </li>
    <li class="page-item"><a class="page-link bg-dark text-light"  href="http://localhost/ondracka_knihovna/Nacteni_seznamu/Seznam_knih/20"><b style="color: skyblue;">2</b></a></li>
    <li class="page-item"><a class="page-link bg-dark text-light"  href="http://localhost/ondracka_knihovna/Nacteni_seznamu/Seznam_knih/40"><b style="color: skyblue;">3</b></a></li>
    <li class="page-item"><a class="page-link bg-dark text-light"  href="http://localhost/ondracka_knihovna/Nacteni_seznamu/Seznam_knih/60"><b style="color: skyblue;">4</b></a></li>
    <li class="page-item"><a class="page-link bg-dark text-light"  href="http://localhost/ondracka_knihovna/Nacteni_seznamu/Seznam_knih/80"><b style="color: skyblue;">5</b></a></li>
    <li class="page-item"><a class="page-link bg-dark text-light"  href="http://localhost/ondracka_knihovna/Nacteni_seznamu/Seznam_knih/100"><b style="color: skyblue;">6</b></a></li>
  </ul>
</nav>
       </div>      
   </div>
   </body>
	
</html> 
