<!DOCTYPE html> 
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
</head>
 
   <head> 
      <meta charset = "utf-8"> 
      <title>Seznam vydavatelu</title> 
      <style>
          table{
              color:red;
              border: 8px solid orange;
          }
      </style>
   </head> 
   <div class="container" style="text-align: center;">
       
       <h1 style="margin-top: 60px; color: skyblue;"><i class="fas fa-book-open bg-dark"></i> SEZNAM VŠECH VYDAVATELŮ </h1>
       <br>
       <br>
       <?php
            $this->load->view('layout/menu');
        ?>
       <div style="margin-top: 50px; text-align: center;" class="bg-dark">
      
		
     <table class="table table-hover table-bordered table-dark" border = "1" style="margin-top: 20px; color: skyblue;" id="dtBasicExample"> 
         <?php
         echo "<tr class='bg-dark text-light'>";
         echo "<td><b>ŠKOLY</b></td>";
         
            foreach($records as $m) { 
          $url = base_url('Nacteni_seznamu/v'.$m->id);
          echo "<tr>";
          echo "<td><a href='$url' style='color: skyblue;'>".$m->nazev."</a></td>";
          echo "<tr>";echo "<tr>";
            } 
            
         ?>
      </table> 
       </div>
       
        </div>
   </body>
	
</html>
