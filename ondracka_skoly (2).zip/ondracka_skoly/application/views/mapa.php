
<!DOCTYPE html >
 <html> <head>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no" />
    <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
    <title>Mapa škol</title>
    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #mapid {
       height: 500px;
       width: 900px;
      }
    </style>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css"
   integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A=="
   crossorigin=""/>
     <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"
   integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA=="
   crossorigin=""></script>
  </head>

<!DOCTYPE html> 
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
</head>
 
   <head> 
      <meta charset = "utf-8"> 
      <title>Mapa škol</title> 
      <style>
          table{
              color:red;
              border: 8px solid orange;
          }
      </style>
   </head> 
    <div class="container" style="text-align: center;">
       <h1 style="margin-top: 60px; color:black;"><i class="fas fa-graduation-cap"></i>MAPA ŠKOL </h1>
       <br>
       <br>
       <?php
            $this->load->view('layout/menu');
        ?>
       <div style="margin-top: 50px; text-align: center;">
  <body>
    <div class="container" id="mapid"></div>
    
    
    <script>
	var mymap = L.map('mapid').setView([49.067068, 17.460288], 10);
	L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw', {
		maxZoom: 18,
		id: 'mapbox/streets-v11',
		tileSize: 512,
		zoomOffset: -1
	}).addTo(mymap); 
  var popup = L.popup(); 
  
    </script>
    
    
      <?php 
            foreach($mapka as $c){
                ?>
               <script> 
               
    L.marker([<?php echo $c->geolat?>,<?php echo $c->geolong?>]).addTo(mymap).bindPopup("<?php echo $c->nazev?>");
    
    
               </script>
      <?php
          }  
       
         ?>
    <script defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBq09Bo_7-tUaH2lErOyE6DFpxtmoUNEaU&callback">
    </script>
       </div>
  </body>
</html>


