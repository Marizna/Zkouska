<!DOCTYPE html> 
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
</head>
 
   <head> 
      <meta charset = "utf-8"> 
      <title>Seznam měst</title> 
      <style>
          table{
              color:red;
              border: 8px solid orange;
          }
      </style>
   </head> 
    <div class="container" style="text-align: center;">
       <h1 style="margin-top: 60px; color:black;"><i class="fas fa-graduation-cap"></i>SEZNAM MĚST </h1>
       <br>
       <br>
       <?php
            $this->load->view('layout/menu');
        ?>
       <div style="margin-top: 50px; text-align: center;">
           
     <table class="table table-hover table-bordered" border = "1" style="margin-top: 20px; color: black;" id="dtBasicExample"> 
         <?php
            echo "<tr class='text-dark'>";
            echo "<td><b>ID</b></td>";
            echo "<td><b>NÁZEV MĚSTA</b></td>";

            foreach($knizka as $c) {
               echo "<tr>";
               echo "<td>".$c->id."</td>";
               echo "<td>".$c->nazev."</td>";      
               }
         ?>
      </table>
</div>
      
       <br>
       </div>
       
        </div>
   </body>
	
</html>
