
<body class="container" style="background-color: #c0c0c0;">
<nav class="navbar navbar-expand-lg navbar-light bg-light ">
    <img src="https://www.iconfinder.com/data/icons/school-icon-set-1/512/1-512.png" width="42" height="35" class="d-inline-block align-top" alt="">    
    <a class="navbar-brand" href="Nacteni_seznamu">&nbsp;&nbsp;</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="skoly">ŠKOLY</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="mesto">MĚSTA</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="obor">OBORY</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="mapa">MAPA ŠKOL</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="zpetna_vazba">ZPĚTNÁ VAZBA</a>
      </li>
  </div>
</nav></body>