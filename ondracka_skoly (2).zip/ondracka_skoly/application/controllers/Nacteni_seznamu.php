<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Nacteni_seznamu extends CI_Controller {

    public function __construct() {
        parent:: __construct();
        $this->load->helper('url');
        $this->load->model('kniha_model');
        $this->load->library("pagination");
    }
     public function index() { 
         $query = $this->db->get("skola"); 
         $data['records'] = $query->result(); 
         $this->load->helper('url'); 
         $this->load->view('layout/index.php',$data);
      } 
       public function skoly(){
           $this->db->order_by('id', 'asc'); 
          $query = $this->db->get('skola');
         $data['records'] = $query->result(); 
         $this->load->helper('url');
         $this->load->view('skoly',$data); 
      }

      
   public function mesto(){
          $this->db->order_by('id', 'asc');
          $query = $this->db->get('mesto');
         $data['knizka'] = $query->result(); 
         $this->load->helper('url');
         $this->load->view('mesto',$data);      
      }
      
       public function obor(){
          $this->db->order_by('id', 'asc');
          $query = $this->db->get('obor');
         $data['knizka'] = $query->result(); 
         $this->load->helper('url');
         $this->load->view('obor',$data);      
      }

      public function zpetna_vazba(){
           $this->db->order_by('id', 'asc'); 
          $query = $this->db->get('zpetna_vazba');
         $data['records'] = $query->result(); 
         $this->load->helper('url');
         $this->load->view('zpetna_vazba',$data); 
      }

        public function pocet(){
        $this->db->order_by('id', 'asc'); 
          $query = $this->db->get('pocet_prijatych');
         $data['records'] = $query->result(); 
         $this->load->helper('url');
         $this->load->view('pocet',$data); 
      }
      
       public function mapa(){ 
         $this->load->helper('url');
         $query = $this->db->get('skola');
         $data['mapka'] = $query->result(); 
         $this->load->view('mapa', $data); 
        
      }
   
      
      
    public function Seznam_knih() {
        $pole = $this->kniha_model->get_count();
        $config["base_url"] = base_url() . "Nacteni_seznamu/Seznam_knih/";
        $config["total_rows"] = $pole;
        $this->db->order_by('nazev', 'ASC');
        $config["per_page"] = 20;
        $config["uri_segment"] = 3;
        $config["num_links"] = 2;
        $this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $data['links'] = $this->pagination->create_links();

        $data['kniha'] = $this->kniha_model->get_kniha($config["per_page"], $page);
        $this->load->view('Seznam_knih', $data);
    }
    



}
