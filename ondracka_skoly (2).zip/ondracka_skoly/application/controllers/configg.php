<?php

$server     = 'localhost';
$username   = 'root';
$password   = '';
$database   = 'skoly';

$dsn        = "mysql:host=$server;dbname=$database";