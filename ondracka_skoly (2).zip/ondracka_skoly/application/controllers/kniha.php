      <style>
    th {
        
       color:white;
    }
   
</style>
<br>
<center>
    
    <h1 style="font-family: monospace; color: #428bca">Zvolená kniha</h1>
</center>
<br>
<div class="container">
      <table class="table table-bordered">
         
        <thead style="background-color: #428bca">
          
            <tr>
       
                <th>Název knihy</th>
                <th>Počet stran</th>
                <th>ISBN</th>
                            
                        </tr>
                    </thead>
                    <?php
            foreach($kniha_vydani as $r) {

            	echo "<tr>";
					echo "<td>" . $r->nazev . "</td>";
					echo "<td>" . $r->strany . "</td>";
					echo "<td>" . $r->isbn . "</td>";
					echo "<tr>";
            }
         ?>
          
      </table>
    <br>

  <div class="row">
      
    <?php foreach ($kniha_vydani as $r): ?>
    <div class="col-4 card border-primary">
        <div class="card-body">
            <ul>
                <dd> <strong>Název knihy:</strong> <?= "{$r->nazev}" ?> </dd>
                <dd> <strong>Počet stran: </strong> <?= $r->strany ?> </dd>
                 <dd> <strong>ISBN</strong> <?= $r->isbn ?> </dd>
            </ul>
        </div>
    </div>
  
    <?php endforeach; ?> 
 
  </div>
</div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>








